# SPATCOM

# This is the computer code corresponding the following publication:

# Title: Spatial scale modulates the inference of metacommunity assembly
# Authors: Duarte S. Viana, Jonathan M. Chase
# Journal: Ecology
# Year: 2018
