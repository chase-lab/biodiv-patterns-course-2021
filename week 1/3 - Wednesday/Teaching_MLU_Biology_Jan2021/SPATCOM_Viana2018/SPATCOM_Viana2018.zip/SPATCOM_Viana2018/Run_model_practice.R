######################
## MLU course ##
#####################

# May 2018
# Practice session
# Duarte Viana

##################################################################################
##################################################################################

# 1. Simulation of community assembly

# Load libraries
library(gstat)
library(sp)
library(plotrix)
library(dplyr)
library(geiger)
library(wrswoR)

# load SPATCOM functions
#setwd("~/Documents/iDiv/Teaching_Clara_May2018/R_code")
source("SPATCOM_functions.R")

##############################################################################################
##############################################################################################

# Examples of dispersal kernel and Gaussian niche shape

# Dispersal
par(mfrow=c(2,1),mar=c(4,4,2,2))
curve(dlnorm(x,0,1),from=0,to=10,lwd=2,col="darkcyan",xlab="Dispersal distance",ylab="Probability")
curve(dlnorm(x,0,5),from=0,to=10,lwd=2,add=T,col="orange")
# Log version
curve(dlnorm(x,0,1),from=0,to=10,log="y",lwd=2,col="darkcyan",xlab="Dispersal distance",ylab="Probability")
curve(dlnorm(x,0,5),from=0,to=10,log="y",lwd=2,add=T,col="orange")

# Niche
par(mfrow=c(2,1),mar=c(4,4,2,2))
curve(dnorm(x,10,1),from=0,to=30,lwd=2,col="darkcyan",xlab="Environment",ylab="Probability")
curve(dnorm(x,20,1),from=0,to=30,lwd=2,add=T,col="orange")
curve(dnorm(x,10,20),from=0,to=30,lwd=2,col="darkcyan",xlab="Environment",ylab="Probability")
curve(dnorm(x,20,20),from=0,to=30,lwd=2,add=T,col="orange")

##############################################################################################
##############################################################################################

# Simulation

# Define initial conditions
#==========================

grid.side <- 50 # number of cells in each side of the quadrangular grid
R <- 30 # number of species (pool)
J <- 0.80 # initial proportion of occupied cells
N_env <- 1 # number of environmental variables
sp_distr <- "random"
cor_env <- 25 # variogram range parameter (spatial correlation in the environment)

# Initialize species
set.seed(49)
spi <- sp.set(grid.side=grid.side,R=R,Ji=J,N_env=N_env,evolve=FALSE,sp.distr=sp_distr)
# Initialize environment
set.seed(79)
envi <- env.set(grid.side=grid.side,R=R,Nenv=N_env,type="mosaic",
                cor.range=cor_env,Nsamples=50)

# Extract useful values
xy <- envi$xy
coords2 <- as.data.frame(envi$coords)
opt2 <- spi$opt
yy.data <- as.data.frame(envi$yy.data[,1:N_env])


# Run model
#==========

# Parameters
D <- 0.01 # mortality rate
M <- 0.5 # productivity (proportion of individuals reproducing)
Z <- 10 # number of dispersed propagules per individual
kern.type <- "lnorm" 
sd.disp <- 0.7 # dispersal capacity (log SD of lognormal kernel)
sd.niche <- 10 # niche breadth (SD of normal distribution)

# Run simulation
set.seed(77)
sp.ini <- spatcom(sp.i=spi,env.i=envi,D=D,M=M,Z=Z,kern.type=kern.type,
                  peak.disp=0,sd.disp=sd.disp,sd.niche=sd.niche,meta.type="SS",G=1000)


##################################################################################
##################################################################################

# 2. Pattern analyses - explore results

# Crop grid to avoid edge effects

# crop the grid and data to avoid edge effects
edge <- 0

# crop - if continuous environment
xyf <- xy[coords2$x>edge&coords2$x<=(grid.side-edge)&coords2$y>edge&coords2$y<=(grid.side-edge)]
sp.ini <- sp.ini[coords2$x>edge&coords2$x<=(grid.side-edge)&coords2$y>edge&coords2$y<=(grid.side-edge)]
yyf <- yy.data[coords2$x>edge&coords2$x<=(grid.side-edge)&coords2$y>edge&coords2$y<=(grid.side-edge),1]

# crop - if discrete environment
#mat.coords.o<-as.data.frame(coordinates(envi$mat.coords))
#sample.id.o<-which(mat.coords.o$x>=edge&mat.coords.o$x<(grid.side-edge) & 
#                     mat.coords.o$y>=edge&mat.coords.o$y<(grid.side-edge))
#mat.coords.o<-mat.coords.o[sample.id.o,]
#cell.id<-envi$sample.id+1
#cell.id.o<-cell.id[cell.id %in% sample.id.o]

#xyf <- xy[which((envi$sample.id+1) %in% sample.id.o),]
#sp.ini <- sp.ini[which((envi$sample.id+1) %in% sample.id.o)]
#yyf <- as.data.frame(yy.data[which((envi$sample.id+1) %in% sample.id.o),1:N_env])



#-----------------------------

# PATTERN METRICS

# Final picture - environment
sp.distr <- SpatialPixelsDataFrame(coordinates(xyf),as.data.frame(yyf))
spplot(sp.distr)

# Final picture - species
fsample.sp <- as.factor(sp.ini)
sp.distr <- SpatialPixelsDataFrame(coordinates(xyf),as.data.frame(fsample.sp))
spplot(sp.distr,col.regions=rainbow(R))

# Regional richness at the end
length(unique(sp.ini[!is.na(sp.ini)]))

# SAD
commt<-sort(table(sp.ini),decreasing=TRUE) # final
barplot(commt)
barplot(log(commt))
plot(1:length(commt),log(commt))


#------------------------------

# PROCESS METRICS

# Load libraries
library(sp)
library(geiger)
library(gstat)
library(vegan)
library(spcosa)
library(rgeos)

# load sampling functions
source("Rcode_sampling functions.R")

# Full extent; all cells included
#============

# PCNM (or MEM) on full extent
xy.df <- data.frame(x=coordinates(xyf)[,1],y=coordinates(xyf)[,2])
xy.pcnm0 <- pcnm(dist(xy.df))
xy.pcnm0 <- as.data.frame(xy.pcnm0$vectors[,which(xy.pcnm0$values>0)])

# Variation partitioning
cell.df <- data.frame(x=coordinates(xyf)[,1],y=coordinates(xyf)[,2],
                      sp=opt2[sp.ini,],env=yyf)
length(which(is.na(cell.df$sp)))
cell.df[which(is.na(cell.df$sp)),"sp"] <- sample(opt2,1)
vp <- varpart(cell.df$sp,cell.df$env,xy.pcnm0)
plot(vp)


# Full extent; discrete sampling
#============

# Build environment and species matrices
samp.ids<-as.numeric(row.names(mat.coords.o))
Nsamples<-nrow(mat.coords.o)

mat.env <- matrix(nrow=Nsamples,ncol=N_env)
mat.sp <- matrix(rep(0,Nsamples*R),nrow=Nsamples,ncol=R)
for(d in 1:Nsamples){
  cellsn <- which(cell.id.o==samp.ids[d])
  if(N_env==1) mat.env[d,] <- mean(yyf[cellsn,1])
  if(N_env>1) mat.env[d,] <- apply(yyf[cellsn,],2,mean)
  sp.abund <- table(sp.ini[cellsn])
  sp.id <- as.numeric(names(sp.abund))
  mat.sp[d,sp.id] <- sp.abund
}

sp.hel <- vegdist(mat.sp,"bray") # beta-diversity

# PCNM
ipcnm <- pcnm(dist(mat.coords.o))
ipcnm <- as.data.frame(ipcnm$vectors[,which(ipcnm$values>0)])

# Multivariate variation partitioning (betadiversity-drivers)
vpi <- varpart(sp.hel,mat.env,ipcnm)
e <- vpi$part$indfract[1,3]
es <- vpi$part$indfract[2,3]
s <- vpi$part$indfract[3,3]
t <- vpi$part$indfract[4,3]

# Print results
c(e,es,s,t)
plot(vpi)





